# Save Sync Integration

Greatly inspired by https://github.com/ZB94/dol_save_server, the original code license is "LICENSE-Original".
Many thanks to their work.
